import Header from '@/components/ui/custom/Header';
import React from 'react'

const Home = () => {
  return (
    <div>
      <Header></Header>
      Landing Screen
    </div>
  )
}

export default Home;
